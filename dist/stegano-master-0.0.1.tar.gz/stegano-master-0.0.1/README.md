# Video Steganography 

Video Steganography in Python for our Information Security Internal Assessment 1
